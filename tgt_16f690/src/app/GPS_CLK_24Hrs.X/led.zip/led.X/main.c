/* 
 * File:   main.c
 * Author: Raja-L
 *
 * Created on 3 April, 2017, 5:16 PM
 */


// CONFIG
#pragma config FOSC = INTRCIO   // Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA4/OSC2/CLKOUT pin, I/O function on RA5/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // MCLR Pin Function Select bit (MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown-out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>

#include <stdio.h>
#include <stdlib.h>
#define _XTAL_FREQ 8000000
#define UART_MAX_RX_SIZE 80
#define UART_RX_MAX_TIMEOUT 200//300 as 3 sec
/*
 * 
 */
unsigned char U16Rx_Write_Index;
unsigned char U16ResponseSize;
char U8Valid_Char,j;
char Receive_buffer[UART_MAX_RX_SIZE];
unsigned int U8_tmr_cnt=0;
unsigned int U8sent_intervel_cnt;
unsigned char Time_Temp1;
unsigned char Time_Temp2;
unsigned char Time_Hr;
unsigned char Time_Min;
unsigned char Time_Sec;
unsigned char offset=0;
char IST_TIME[9];char IST_TIME1[9];
unsigned char Temp_Cnt=0;
unsigned int i;

void INIT();
void IST_Time_Formate();
char Time_Formate_to_STR();
void UARTReceiveInterrupt();
unsigned char UARTReceiveddatasize();
void UARTResetRxBuffer();

void interrupt ISR(void)
{      
    if(RCIE && RCIF)
    {   
        UARTReceiveInterrupt(); 
        RCIF = 0;
        
    }        
}

void main() 
{
    INIT();
    while(1)
    {
   
    if(UARTReceiveddatasize() > 8)
    {
        UARTResetRxBuffer(); IST_Time_Formate(); Time_Formate_to_STR();
    PORTC=IST_TIME1[0]; PORTA=0x0E;      __delay_ms(100); PORTA=0xFF; PORTBbits.RB4=1;PORTBbits.RB6=1;
    PORTC=IST_TIME1[1]; PORTA=0x0D;      __delay_ms(100); PORTA=0xFF; PORTBbits.RB4=1;PORTBbits.RB6=1;
    PORTC=IST_TIME1[3]; PORTA=0x0B;      __delay_ms(100); PORTA=0xFF; PORTBbits.RB4=1;PORTBbits.RB6=1;
    PORTC=IST_TIME1[4]; PORTA=0x07;      __delay_ms(100); PORTA=0xFF; PORTBbits.RB4=1;PORTBbits.RB6=1;
    PORTC=IST_TIME1[6]; PORTBbits.RB4=0; __delay_ms(100); PORTA=0xFF; PORTBbits.RB4=1;PORTBbits.RB6=1;
    PORTC=IST_TIME1[7]; PORTBbits.RB6=0; __delay_ms(100); PORTA=0xFF; PORTBbits.RB4=1;PORTBbits.RB6=1;

      }
    
    
    }
}



unsigned char UARTReceiveddatasize()
{
	return U16ResponseSize;
} 

void UARTResetRxBuffer()
{
     U16Rx_Write_Index=0;	  
	 U16ResponseSize=0;	 
}
void UARTReceiveInterrupt()
{				
        unsigned char temp;
        temp = RCREG;
        if(temp == '$')
            U8Valid_Char=1;
        else if(U8Valid_Char == 1){
           if(temp == 'G')
               U8Valid_Char=2;
        }
        else if(U8Valid_Char == 2){
           if(temp == 'P')
               U8Valid_Char=3;
        }
        else if(U8Valid_Char == 3){
           if(temp == 'G')
               U8Valid_Char=4;
        }
        else if(U8Valid_Char == 4){
           if(temp == 'G')
               U8Valid_Char=5;
        }
        else if(U8Valid_Char == 5){
           if(temp == 'A')
               U8Valid_Char=6;
        }
        else if(U8Valid_Char == 6){
           if(temp == ',')
               U8Valid_Char=8; 
        }
        else if(U8Valid_Char == 8){
            //UARTsendBuffer("hai raja");
            //UARTsendByte(temp);
            Receive_buffer[U16Rx_Write_Index] = temp;
            U16Rx_Write_Index++;  				
		    U16ResponseSize = U16Rx_Write_Index;
            if(U16ResponseSize > 8){
                U8Valid_Char=0;//UARTInterruptDisable();
            }
        } 
           
}

void INIT()
{
    OSCCON=0X75;
    OSCTUNE=0X0F;
    TRISA=0;
    TRISC=0;
    TRISB=0;
    ANSEL=0;
    ANSELH=0;
    GIE=1;
  	PEIE=1;
    SPEN = 1;
    TRISB5=1;   
	TXSTA=0x28;
    RCSTA=0x80;    
    SPBRG=12;    
    RCIE=1;
    RCIF=0;  
    CREN = 1;
    INTE = 1;
    
    //TXSTA=0x28;
    //RCST=0x0
}
char Time_Formate_to_STR()
{
  IST_TIME[0]=(Time_Hr/10) + 48;
  IST_TIME[1]=(Time_Hr%10) + 48;
  IST_TIME[2]=':';
  IST_TIME[3]=(Time_Min/10) + 48;
  IST_TIME[4]=(Time_Min%10) + 48;
  IST_TIME[5]=':';
  IST_TIME[6]=(Time_Sec/10)+48;
  IST_TIME[7]=(Time_Sec%10)+48;
  IST_TIME[8]='\0';
  
  for(int i=0; i < 9; i++)
  {
    IST_TIME1[i]=IST_TIME[i] - 48;
  }
  
}
void IST_Time_Formate()
{
    Time_Temp1=Receive_buffer[0]-48;
    Time_Temp2=Receive_buffer[1]-48;
    Time_Hr=(Time_Temp1*10)+Time_Temp2+5;
    Time_Temp1=Receive_buffer[2]-48;
    Time_Temp2=Receive_buffer[3]-48;
    Time_Min=(Time_Temp1*10)+Time_Temp2;
    Time_Min=Time_Min+30;
    Time_Temp1=Receive_buffer[4]-48;
    Time_Temp2=Receive_buffer[5]-48;
    Time_Sec=(Time_Temp1*10)+Time_Temp2;
    
    if(Time_Min > 60)
    {
     Time_Min = Time_Min -60;//(60 - Time_Min);
     offset=1;
    }
    else
     offset=0;
    
    if(Time_Hr > 24)
    {
     Time_Hr = (24-Time_Hr) + offset;
     offset=0;
    }      
////////////////////    
}